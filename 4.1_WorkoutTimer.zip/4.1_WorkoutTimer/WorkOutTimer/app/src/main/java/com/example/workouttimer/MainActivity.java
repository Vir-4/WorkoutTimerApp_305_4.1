package com.example.workouttimer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Chronometer timer;
    TextView heading;
    EditText workouttype;

    String timetostring,workout,topline;

    long timepassed,pauseOffset,stopOffset;
    boolean timerrunning,timepaused;

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putLong("L_pauseOffset",pauseOffset);
        outState.putLong("L_timepassed",timepassed);
        outState.putBoolean("L_timerrunning",timerrunning);
        outState.putString("L_workouttype",workouttype.getText().toString());
        outState.putString("L_heading",heading.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        pauseOffset=savedInstanceState.getLong("L_pauseOffset");
        timepassed=savedInstanceState.getLong("L_timepassed");
        timerrunning=savedInstanceState.getBoolean("L_timerrunning");
        workout=savedInstanceState.getString("L_workouttype");
        topline=savedInstanceState.getString("L_heading");

        if (timerrunning)
        {
            timer.setBase(timepassed);
            timer.start();
        }
        else if(!timerrunning)
        {
            long L_second=(pauseOffset/1000)%60;
            long L_minute=(pauseOffset/1000)/60;
            long L_hour=(pauseOffset/1000)/3600;
            timer.setText(String.format("%02d:%02d:%02d",L_hour,L_minute,L_second));
            heading.setText(topline);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timer=findViewById(R.id.timer);
        heading=findViewById(R.id.textView);
        workouttype=findViewById(R.id.workouttype);

    }
    public void Switch(View view)
    {
        switch (view.getId())
        {
            case R.id.playbutton:
                if(!timerrunning)
                {
                    timer.setBase(SystemClock.elapsedRealtime()-pauseOffset);
                    timer.start();
                    timepassed=SystemClock.elapsedRealtime()-pauseOffset;
                    timerrunning=true;
                }
                else
                {
                    Toast.makeText(MainActivity.this,"timer already started!",Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.pausebutton:
                if(timerrunning)
                {
                    timer.stop();
                    pauseOffset=SystemClock.elapsedRealtime()-timer.getBase();
                    timerrunning=false;
                    timepaused=false;
                }
                else
                {
                    Toast.makeText(MainActivity.this,"timer already paused!",Toast.LENGTH_SHORT).show();
                }
                break;

            case  R.id.stopbutton:
                if(timerrunning)
                {
                    timer.stop();
                    stopOffset=SystemClock.elapsedRealtime()-timer.getBase();
                    long second=(stopOffset/1000)%60;
                    long minute=(stopOffset/1000)/60;
                    long hour=(stopOffset/1000)/3600;
                    timetostring=String.format("%02d:%02d:%02d",hour,minute,second);
                    timerrunning=false;
                }
                else
                {
                    if(!timepaused)
                    {
                        long seconds=(pauseOffset/1000)%60;
                        long minutes=(pauseOffset/1000)/60;
                        long hours=(pauseOffset/1000)/3600;
                        timetostring=String.format("%02d:%02d:%02d",hours,minutes,seconds);
                        timepaused=true;
                    }
                }
                timer.setBase(SystemClock.elapsedRealtime());
                pauseOffset=0;
                timerrunning=false;
                stopOffset=0;
                if(workouttype.getText().toString().isEmpty())
                {
                    workouttype.setText("nothing");
                }
                heading.setText("You spent "+timetostring+" on "+workouttype.getText().toString()+" last time");
                break;

                default:
                throw new IllegalStateException("ILLEGAL STATE EXCEPTION");
        }
    }

}